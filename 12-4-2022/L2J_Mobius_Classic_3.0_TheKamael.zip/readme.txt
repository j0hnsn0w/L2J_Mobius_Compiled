L2J-Mobius The Kamael

JDK: https://www.mediafire.com/file/kb2nfx54wojys4f/bellsoft-jdk17.0.2%252B9-windows-amd64.msi
XAMPP: https://www.mediafire.com/file/hkehxpyjn81ybsw/xampp-windows-x64-8.0.11-2-VS16-installer.exe
Eclipse: https://www.mediafire.com/file/j208qw3s7zwx7c7/eclipse-java-2021-12-R-win32-x86_64.zip
Geodata: http://www.mediafire.com/file/67p627w8qmalsbs/L2J_Mobius_Classic_3.0_TheKamael_Geodata.zip

Client (password L2jMobius): https://drive.google.com/u/1/uc?id=1FpOy82whmZdQacf4ZAjRsyc6sWYq14in&export=download
System: https://mega.nz/file/cxs3DSpa#v_PXYHDULpwSP_P_l-ppgn0SP87uN4__X5gcNcZWtFk

All provided download links are for personal use. Redistribution of these links is bannable.


Saviors: https://eu.4game.com/lineage2classic/play/saviors/
-Classic packet compatibility
-Parsed item data from client
-Proper Daily Mission rewards
-Zone changes to match starting locations
-Parsed recipes from client
-Parsed skill names from client
-Parsed NPC names from client
-Temporary NPC info from Interlude retail files
-Temporary spawns from Interlude retail files
-Further manual spawn fixes
-Skilltrees info from L2Wiki
-Parsed NPC droplists from L2Wiki
-Further manual NPC corrections from L2Wiki
-Retail NPC dialogs
-Retail NPC buylists
-Basic Tutorial quest
-Added 156 quest scripts
-Village Master AI scripts
-Fixed skill levels to match retail
-Added new class mounts
-Fisherman NPC updates
-Fixed fishing to match retail
-Added new fishing zone locations
-Quest Fishing Specialist's Request
-Olympiad NPC updates
-Dimensional Merchant updates
-Classic gatekeeper teleports
-Admin menu teleport and shop cleanups
-Blacksmith NPC updates
-New Race Track arena zone
-Giran Luxury Shop updates
-Grandboss scripts and stats
-Whisper of Dreams quests
-Moon Knight quest
-Item augmentation support
-Retail Henna list
-Floran Agricultural Area clan halls
-Maille Lizardmen Barracks clan halls
-Augmentation chances from L2Wiki
-Working Runes system
-Added new Savior skills
-Classic 3rd class quests
-Dungeon of Abyss
-Attendance rewards
-Various retail Classic events
-Classic Olympiad shedule
-Ruin area herb drops

Zaken: https://eu.4game.com/lineage2classic/play/zaken/
-Parsed new system messages and npc strings from client.
-Parsed new skills from client
-Parsed new items from client
-Parsed new NPCs from L2Wiki
-Parsed recipes from client
-Added raidbosses according to map
-Giants Cave
-Zaken boss AI
-Newbie quest changes

Antharas: https://eu.4game.com/lineage2classic/play/antharas/
-Parsed new system messages and npc strings from client.
-Parsed new skills from client
-Parsed new items from client
-Parsed new NPCs from L2Wiki and client
-Clan Arena
-New Agathion item support

Seven Signs: https://eu.4gameforum.com/threads/658543/
-Parsed new system messages and npc strings from client
-Parsed new skills from client
-Parsed new items from client
-Parsed new NPCs from client
-Updated skiltrees and skills from L2Wiki
-Updated experience values from L2Wiki
-Elemental Spirits
-Elemental Spirit boss instances
-Land of Winds spawns
-Goddard territory spawns
-Goddard clanhalls

Secret of Empire: https://eu.4game.com/patchnotes/lineage2classic/133/
-Parsed new system messages and npc strings from client
-Parsed new skills from client
-Parsed new items from client
-Parsed new recipes from client
-Imperial tomb area spawns
-Retail gatekeeper teleports
-Equipment upgrade system

The Kamael: https://eu.4game.com/patchnotes/lineage2classic/154/
-Kamael creation support
-Teleport list system
-Removed item grade penalty
-New starting quests
-Auto attack system
-Auto potion system
-Rank system

Customs:
-Newbie Helper NPC location info
-Newbie Helper buff support until 40 level
-Test Server Helper NPCs
-Fake players engine
