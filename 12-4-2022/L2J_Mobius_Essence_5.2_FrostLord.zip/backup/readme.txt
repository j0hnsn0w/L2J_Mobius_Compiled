MySQL backups are stored in this folder.
Separate game and login server backups are possible.
Just enable the 'BackupDatabase' option in the equivalent server config file.