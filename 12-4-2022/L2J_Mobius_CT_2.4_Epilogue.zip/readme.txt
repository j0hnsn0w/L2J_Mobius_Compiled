L2J-Mobius Epilogue

JDK: https://www.mediafire.com/file/kb2nfx54wojys4f/bellsoft-jdk17.0.2%252B9-windows-amd64.msi
XAMPP: https://www.mediafire.com/file/hkehxpyjn81ybsw/xampp-windows-x64-8.0.11-2-VS16-installer.exe
Eclipse: https://www.mediafire.com/file/j208qw3s7zwx7c7/eclipse-java-2021-12-R-win32-x86_64.zip
Geodata: http://www.mediafire.com/file/q515p4hl6j0ivxm/L2J_Mobius_CT_2.4_Epilogue_Geodata.zip

Client (password L2jMobius): https://drive.google.com/u/1/uc?id=10cLvBIhj5mL_ldtRrEYSHpg-FZBv-ady&export=download
System: https://mega.nz/#!ppkUFIJQ!oat-UGQsf2liToQu19nCljGO5BAUInwfzln-ERBBB28

All provided download links are for personal use. Redistribution of these links is bannable.


What is done
-Removed HighFive packets.
-Adjusted packets to match client.
-Removed Nevit system.
-Replaced Olympiad with older version.
-Replaced Frintezza AI with older version.
-Removed Freya instances.
-Removed Zaken 83 instance.
-Removed Kamaloka 83 instance.
-Removed Seed of Annihilation.
-Removed level 16+ crystal level-up data.
-Updated doors data.
-Replaced item auction data with older version.
-Replaced character birthday event with older version.
-Prevent adding more than one element attribute.
-Adjusted boat message broadcasting.
-Adjusted gain exp/sp message notification.
-Added method for using NpcStrings as text.
-Removed Moirai, Vorpal and Elegia armor sets.
-Removed non existent client drops.
-Various item corrections based on retail information.
-Various skill corrections based on retail information.
-Skilltree changes based on retail information.
-Changed experience data according to older version.
-Removed non existent enchant item data.
-Corrections for S80 grade items.
-Beast spice corrections.
-Increased ToI vortex crystal price.
-Addition of old treasure chests.
-Adjusted NPC templates to match client.
-Luxury shop reverted to older version.
-Fantasy Island shop reverted to older version.
-Removed Fantasy Isle Magic Zone.
-Removed shots and keys from grocery shops.
-Blacksmiths unseal B grade items.
-Removed recipe traders.
-Adjusted mammon shop to match older version.
-Other various shops reverted to older versions.
-Teleporter adjustments to match older version.
-Reduced ongoing quests limit to 25.
-Removed non existent client quests.
-Parsed NPC names from client.
-Removed non existent client NPC spawns.
-Removed non existent raibosses.
-Plains of the Lizardmen spawns.
-Skyshadow Meadow spawns.
-BeastFarm spawns.
-Pavel Ruins, Archaic Laboratory spawns.
-Dragon Valley spawns.
-Antharas Lair spawns.
-Monastery of Silence spawns.
-Replaced Monastery of Silence AI with older version.
-Community board html adjustments.
-Proper Path to Becoming a Lord Schuttgart (714) kill ids.
-Older versions of Possessor of a Precious Soul 1 and 3 quests.
-Older versions for quests 19, 631, 647.
-Retail CP base stat values.
-Retail recommendation system.
-Removed AltarsOfSacrifice AI.
-Removed non existent vesper shield set Verteidiger skill.