DELETE FROM skill_trees WHERE skill_id>=370 AND skill_id<461;
DELETE FROM skill_trees WHERE skill_id>=1374 AND skill_id<1430;
DELETE FROM skill_trees WHERE skill_id>=2234 AND skill_id<2328;
DELETE FROM skill_trees WHERE skill_id>=3080 AND skill_id<3266;
DELETE FROM skill_trees WHERE skill_id>=3603 AND skill_id<3633;
DELETE FROM skill_trees WHERE skill_id>=4989 AND skill_id<7000;
DELETE FROM skill_trees WHERE skill_id>=7033 AND skill_id<7064;

DELETE FROM npcskills WHERE skillid>=370 AND skillid<461;
DELETE FROM npcskills WHERE skillid>=1374 AND skillid<1430;
DELETE FROM npcskills WHERE skillid>=2234 AND skillid<2328;
DELETE FROM npcskills WHERE skillid>=3080 AND skillid<3266;
DELETE FROM npcskills WHERE skillid>=3603 AND skillid<3633;
DELETE FROM npcskills WHERE skillid>=4989 AND skillid<7000;
DELETE FROM npcskills WHERE skillid>=7033 AND skillid<7064;
