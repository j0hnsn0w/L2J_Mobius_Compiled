-- Remove Schuttgart teleports.
DELETE FROM `teleport` WHERE `Description` like '%Schuttgart%';
