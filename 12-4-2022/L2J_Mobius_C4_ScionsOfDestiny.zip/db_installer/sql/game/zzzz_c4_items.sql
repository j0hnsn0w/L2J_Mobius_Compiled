DELETE FROM droplist WHERE itemId>7849;

DELETE FROM skill_spellbooks WHERE item_id>7849;

DELETE FROM merchant_buylists WHERE item_id>7849;
