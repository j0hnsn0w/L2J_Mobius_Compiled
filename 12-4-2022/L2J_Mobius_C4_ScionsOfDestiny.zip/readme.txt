L2J-Mobius C4
Base idea is to use C6 branch for C4 client.

JDK: https://www.mediafire.com/file/kb2nfx54wojys4f/bellsoft-jdk17.0.2%252B9-windows-amd64.msi
XAMPP: https://www.mediafire.com/file/hkehxpyjn81ybsw/xampp-windows-x64-8.0.11-2-VS16-installer.exe
Eclipse: https://www.mediafire.com/file/j208qw3s7zwx7c7/eclipse-java-2021-12-R-win32-x86_64.zip
Geodata: http://www.mediafire.com/file/q0j6uawuq5fjo0k/L2J_Mobius_C4_ScionsOfDestiny_Geodata.zip

Client (password L2jMobius): https://drive.google.com/u/0/uc?id=1c5MoWXtlbWaITxhe_d7G6gE7uf0wSYh4&export=download
System: https://mega.nz/file/c09XTS7Y#MoIzoOZ8q-aAiKuE4XzB4JpJU67Eql61SHD4VhqP9Mw

All provided download links are for personal use. Redistribution of these links is bannable.


Prelude: http://legacy.lineage2.com/news/career.html
Territories: Sea of Spores, The Ivory Tower, Oren Castle & Town, Hunters' Village, Forgotten Temple.
Class transfer system.
Summons and pets.
Clan / Alliance system.
Player item stores.

Chronicle 1: http://legacy.lineage2.com/news/chronicle1_01.html
Territories: Aden Castle & Town, Cave of Giants, Angel Waterfall, Forest of Mirrors, Cemetery of Kings, Sealing of Shilen, Blazing Swamp, Tower of Insolence, Lair of Antharas, Hardin's Academy, Giran Harbor, Bandit Stronghold.
Castle Siege system.
Weight System.
Antharas raid.
Clan Halls system.

Chronicle 2: http://legacy.lineage2.com/news/chronicle2_01.html
Territories: Field of Silence, Field of Whispers, Eva's Underwater Garden, Alligator Island, Heine the Floating City, Pirate Tunnel, Devil's Isle, Coliseum, Devastated Castle.
Castle thrones, destroyable walls and traps.
Manor system.
Mini games Monster race, Lottery, Dice.
Broadcast Towers.
Swiming.
Baium raid.
Zaken raid.
Treasure Chest and Mimic.
Hunting ground guards.
Dyes and Symbols.
Devastated Castle.
Macros system.
Item Manufacturing system.
Player recommendations.
Boat system.

Chronicle 3: http://legacy.lineage2.com/news/chronicle3_01.html
Seven Signs.
Clan Hall Decorations system.
Special Abilities Options for Weapons.
Trial of Equipment.
Anakim and Lilith raids.
Community board mail system.
Community board friends system.
Subclass system.
New Player Bonuses.
Equipment Exchange.

Chronicle 4: http://legacy.lineage2.com/news/chronicle4_01.html
Territories: Varka Silenos Outpost, Ketra Orc Outpost, Wall of Argos, Imperial Tomb, Hot Springs, Forge of the Gods, Garden of Beasts, Devil's Pass, Valley of the Saints, Beast Farm, Forest of the Dead, Swamp of Screams.
Noblesse.
Heroes and Olympiad.
Skill Enchanting.
Valakas raid.
Dimensional Rift.
Fishing system.
Clan Wars system.
Adventurer's Guildsman.
Recording Gameplay.
Community Clan search.

Chronicle 5: http://legacy.lineage2.com/news/chronicle5_01.html
Removed - Territories: The Pagan Temple, The Stakato Nest, The Monastery of Silence, The Frozen Labyrinth, The Den of Evil, The Plunderous Plains, The Ice Queen's Castle, The Crypts of Disgrace, The Pavel Ruins
Removed - Rune Castle's Benom.
Gatekeeper Ordinary, Noblesse, Clan Hall and Seven Signs Priest teleports.
Removed - Frintezza raid.
Removed - The Demonic Sword Zariche.
Removed - Fishing King Championship Tournament Event.
Wild Beast Reserve.
Fortress of the Dead.
Rainbow Springs Chateau.

Interlude: http://legacy.lineage2.com/news/interlude_01.html
Removed - Weapon Augmentation system.
Removed - Primeval Isle.
Removed - Primeval Isle's Tyrannosaurus Trapping System.
Removed - Shadow Weapons.
Removed - Blood Sword Akamanah.
Command Channel system.
Removed - Dueling system.
Removed - Herb item drops. https://lineage.pmfun.com/list/c5c6


TODO:
Drop knownlists -> Use World.
