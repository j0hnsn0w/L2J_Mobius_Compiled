DROP TABLE IF EXISTS `fishing_championship`;
CREATE TABLE IF NOT EXISTS `fishing_championship` (
  `player_name` VARCHAR(35) NOT NULL,
  `fish_length` DOUBLE(10,3) NOT NULL,
  `rewarded` INT(1) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;