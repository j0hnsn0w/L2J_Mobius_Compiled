L2J-Mobius High Five

JDK: https://www.mediafire.com/file/kb2nfx54wojys4f/bellsoft-jdk17.0.2%252B9-windows-amd64.msi
XAMPP: https://www.mediafire.com/file/hkehxpyjn81ybsw/xampp-windows-x64-8.0.11-2-VS16-installer.exe
Eclipse: https://www.mediafire.com/file/j208qw3s7zwx7c7/eclipse-java-2021-12-R-win32-x86_64.zip
Geodata: http://www.mediafire.com/file/92t2tdjni4rux06/L2J_Mobius_CT_2.6_HighFive_Geodata.zip

Client (password L2jMobius): https://drive.google.com/u/0/uc?id=1anK5v2JPq4dxZQcA5ofA5ip82eBPtELb&export=download
System: https://mega.nz/file/B5sVlTgJ#a19JJWZ7llbAZF9XnU91Z98ZbO_Rb56s9AvQ_QyDz-c

All provided download links are for personal use. Redistribution of these links is bannable.


What is done
-Dropped Python / Javolution / Trove
-Nevit system
-Tutorial quest in Java
-Pailaka Injured Dragon quest
-All Seven Sign quests
-Gracia instances
-Freya grandboss
-Castle dungeon instances
-High Five treasure boxes
-Fixed server lag on many occasions
-Auto potions voiced command
-Store offline trader transactions in realtime
-Minimum range config for private stores
-Random spawn system for monsters
-Custom starting location
-Custom community board
-Custom Olympiad period
-Premium System
-User command expon/expoff
-Reworked drop system
-Retail system messages and NPC strings
-New script loader
-New ThreadPool
-New XML reader
-Replaced MMOCore with Netty
-Dropped SQL spawnlist
-Sell buffs command
-Dropped knownlists
-Faction System (Good vs Evil)
-Fake players
-Automated database backups
-Reworked World, WorldRegion and WorldObject
