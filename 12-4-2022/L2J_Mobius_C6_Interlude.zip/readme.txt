L2J-Mobius Interlude
Project concept is to use L2jFrozen as base
and make improvements, or modernize code, without breaking server functionality.

JDK: https://www.mediafire.com/file/kb2nfx54wojys4f/bellsoft-jdk17.0.2%252B9-windows-amd64.msi
XAMPP: https://www.mediafire.com/file/hkehxpyjn81ybsw/xampp-windows-x64-8.0.11-2-VS16-installer.exe
Eclipse: https://www.mediafire.com/file/j208qw3s7zwx7c7/eclipse-java-2021-12-R-win32-x86_64.zip
Geodata: http://www.mediafire.com/file/4k2pi3qa8rqt299/L2J_Mobius_C6_Interlude_Geodata.zip

Client (password L2jMobius): https://drive.google.com/u/2/uc?id=1zCGzxWgkxASntc_X8L4YCEqk9hDc5VBN&export=download
System: https://mega.nz/#!t49wiKgZ!PzVAcxcg2o8gRkAiMjH7CUO6lKrBG27npg2JPL1uEq8

All provided download links are for personal use. Redistribution of these links is bannable.


Prelude: http://legacy.lineage2.com/news/career.html
Territories: Sea of Spores, The Ivory Tower, Oren Castle & Town, Hunters' Village, Forgotten Temple.
Class transfer system.
Summons and pets.
Clan / Alliance system.
Player item stores.

Chronicle 1: http://legacy.lineage2.com/news/chronicle1_01.html
Territories: Aden Castle & Town, Cave of Giants, Angel Waterfall, Forest of Mirrors, Cemetery of Kings, Sealing of Shilen, Blazing Swamp, Tower of Insolence, Lair of Antharas, Hardin's Academy, Giran Harbor, Bandit Stronghold.
Castle Siege system.
Weight System.
Antharas raid.
Clan Halls system.

Chronicle 2: http://legacy.lineage2.com/news/chronicle2_01.html
Territories: Field of Silence, Field of Whispers, Eva's Underwater Garden, Alligator Island, Heine the Floating City, Pirate Tunnel, Devil's Isle, Coliseum, Devastated Castle.
Castle thrones, destroyable walls and traps.
Manor system.
Mini games Monster race, Lottery, Dice.
Broadcast Towers.
Swiming.
Baium raid.
Zaken raid.
Treasure Chest and Mimic.
Hunting ground guards.
Dyes and Symbols.
Devastated Castle.
Macros system.
Item Manufacturing system.
Player recommendations.
Boat system.

Chronicle 3: http://legacy.lineage2.com/news/chronicle3_01.html
Seven Signs.
Clan Hall Decorations system.
Special Abilities Options for Weapons.
Trial of Equipment.
Anakim and Lilith raids.
Community board mail system.
Community board friends system.
Subclass system.
New Player Bonuses.
Equipment Exchange.

Chronicle 4: http://legacy.lineage2.com/news/chronicle4_01.html
Territories: Varka Silenos Outpost, Ketra Orc Outpost, Wall of Argos, Imperial Tomb, Hot Springs, Forge of the Gods, Garden of Beasts, Devil's Pass, Valley of the Saints, Beast Farm, Forest of the Dead, Swamp of Screams.
Noblesse.
Heroes and Olympiad.
Skill Enchanting.
Valakas raid.
Dimensional Rift.
Fishing system.
Clan Wars system.
Adventurer's Guildsman.
Recording Gameplay.
Community Clan search.

Chronicle 5: http://legacy.lineage2.com/news/chronicle5_01.html
Territories: The Pagan Temple, The Stakato Nest, The Monastery of Silence, The Frozen Labyrinth, The Den of Evil, The Plunderous Plains, The Ice Queen's Castle, The Crypts of Disgrace, The Pavel Ruins
Rune Castle's Benom.
Gatekeeper Ordinary, Noblesse, Clan Hall and Seven Signs Priest teleports.
Frintezza raid.
The Demonic Sword Zariche.
Fishing King Championship Tournament Event.
Wild Beast Reserve.
Fortress of the Dead.
Rainbow Springs Chateau.

Interlude: http://legacy.lineage2.com/news/interlude_01.html
Weapon Augmentation system.
Primeval Isle.
Primeval Isle's Tyrannosaurus Trapping System.
Shadow Weapons.
Blood Sword Akamanah.
Command Channel system.
Dueling system.
Herb item drops. https://lineage.pmfun.com/list/c5c6


TODO:
Drop knownlists -> Use World.
