CREATE TABLE IF NOT EXISTS `custom_notspawned` (
  `id` int(11) NOT NULL,
  `isCustom` int(1) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;