#! /bin/sh

./ServerTask.sh &